package com.caio.agenda.view;

public class MenuPrincipal {

    public static void bemVindo() {
        System.out.println("Seja bem-vindo a agenda de contatos");
        System.out.println("-----------------------------");
    }

    public static void exibir() {
        System.out.println("Escolha uma opcao");
        System.out.println("1 - Para listar todos os contatos");
        System.out.println("2 - Para adicionar um contato");
        System.out.println("3 - Para buscar por um contato");
        System.out.println("4 - Para deletar um contato");
        System.out.println("5 - Para deletar todos os  contatos");
    }
}
